/*
 * MutableStock.java
 *
 * Created on June 8, 2007, 9:58 PM
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Copyright (C) 2007 Cheok YanCheng <yccheok@yahoo.com>
 */

package org.yccheok.jstock.gui;

import org.yccheok.jstock.engine.*;

/**
 *
 * @author yccheok
 */
public class MutableStock {
    
    /** Creates a new instance of MutableStock */
    public MutableStock(Stock stock) {
        this.stock = stock;
    }
    
    public Stock getStock() {
        return this.stock;
    }
    
    public Code getCode() {
        return stock.getCode();
    }

    public Symbol getSymbol() {
        return stock.getSymbol();
    }

    public String getName() {
        return stock.getName();
    }

    public Stock.Board getBoard() {
        return stock.getBoard();
    }
    
    public Stock.Industry getIndustry() {
        return stock.getIndustry();
    }

    public double getOpenPrice() {
        return stock.getOpenPrice();
    }

    public double getPrevPrice() {
        return stock.getPrevPrice();
    }

    public double getLastPrice() {
        return stock.getLastPrice();
    }

    public double getHighPrice() {
        return stock.getHighPrice();
    }

    public double getLowPrice() {
        return stock.getLowPrice();
    }

    // TODO: CRITICAL LONG BUG REVISED NEEDED.
    public long getVolume() {
        return stock.getVolume();
    }

    public double getChangePrice() {
        return stock.getChangePrice();
    }

    public double getChangePricePercentage() {
        return stock.getChangePricePercentage();
    }

    public int getLastVolume() {
        return stock.getLastVolume();
    }

    public double getBuyPrice() {
        return stock.getBuyPrice();
    }

    public int getBuyQuantity() {
        return stock.getBuyQuantity();
    }

    public double getSellPrice() {
        return stock.getSellPrice();
    }

    public int getSellQuantity() {
        return stock.getSellQuantity();
    }
    
    public double getSecondBuyPrice() {
        return stock.getSecondBuyPrice();
    }
    
    public int getSecondBuyQuantity() {
        return stock.getSecondBuyQuantity();
    }
    
    public double getSecondSellPrice() {
        return stock.getSecondSellPrice();
    }
    
    public int getSecondSellQuantity() {
        return stock.getSecondSellQuantity();
    }
    
    public double getThirdBuyPrice() {
        return stock.getThirdBuyPrice();
    }
    
    public int getThirdBuyQuantity() {
        return stock.getThirdBuyQuantity();
    }
    
    public double getThirdSellPrice() {
        return stock.getThirdSellPrice();
    }
    
    public int getThirdSellQuantity() {
        return stock.getThirdSellQuantity();
    }   
    
    public String toString() {
        return stock.toString();
    }

    /*
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getOpenPrice(),
                stock.getLastPrice(),
                stock.getHighPrice(),
                stock.getLowPrice(),
                stock.getVolume(),
                stock.getChangePrice(),
                stock.getChangePricePercentage(),
                stock.getLastVolume(),
                stock.getBuyPrice(),
                stock.getBuyQuantity(),
                stock.getSellPrice(),
                stock.getSellQuantity(),
                stock.getSecondBuyPrice(),
                stock.getSecondBuyQuantity(),
                stock.getSecondSellPrice(),
                stock.getSecondSellQuantity(),
                stock.getThirdBuyPrice(),
                stock.getThirdBuyQuantity(),
                stock.getThirdSellPrice(),
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );
     */
    public void setOpenPrice(double openPrice) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getPrevPrice(),
                openPrice,
                stock.getLastPrice(),
                stock.getHighPrice(),
                stock.getLowPrice(),
                stock.getVolume(),
                stock.getChangePrice(),
                stock.getChangePricePercentage(),
                stock.getLastVolume(),
                stock.getBuyPrice(),
                stock.getBuyQuantity(),
                stock.getSellPrice(),
                stock.getSellQuantity(),
                stock.getSecondBuyPrice(),
                stock.getSecondBuyQuantity(),
                stock.getSecondSellPrice(),
                stock.getSecondSellQuantity(),
                stock.getThirdBuyPrice(),
                stock.getThirdBuyQuantity(),
                stock.getThirdSellPrice(),
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );
        
        this.stock = s;
    }

    public void setPrevPrice(double prevPrice) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                prevPrice,
                stock.getOpenPrice(),
                stock.getLastPrice(),
                stock.getHighPrice(),
                stock.getLowPrice(),
                stock.getVolume(),
                stock.getChangePrice(),
                stock.getChangePricePercentage(),
                stock.getLastVolume(),
                stock.getBuyPrice(),
                stock.getBuyQuantity(),
                stock.getSellPrice(),
                stock.getSellQuantity(),
                stock.getSecondBuyPrice(),
                stock.getSecondBuyQuantity(),
                stock.getSecondSellPrice(),
                stock.getSecondSellQuantity(),
                stock.getThirdBuyPrice(),
                stock.getThirdBuyQuantity(),
                stock.getThirdSellPrice(),
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );

        this.stock = s;
    }
    
    public void setLastPrice(double lastPrice) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getPrevPrice(),
                stock.getOpenPrice(),
                lastPrice,
                stock.getHighPrice(),
                stock.getLowPrice(),
                stock.getVolume(),
                stock.getChangePrice(),
                stock.getChangePricePercentage(),
                stock.getLastVolume(),
                stock.getBuyPrice(),
                stock.getBuyQuantity(),
                stock.getSellPrice(),
                stock.getSellQuantity(),
                stock.getSecondBuyPrice(),
                stock.getSecondBuyQuantity(),
                stock.getSecondSellPrice(),
                stock.getSecondSellQuantity(),
                stock.getThirdBuyPrice(),
                stock.getThirdBuyQuantity(),
                stock.getThirdSellPrice(),
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );
        
        this.stock = s;
    }
    
    public void setHighPrice(double highPrice) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getPrevPrice(),
                stock.getOpenPrice(),
                stock.getLastPrice(),
                highPrice,
                stock.getLowPrice(),
                stock.getVolume(),
                stock.getChangePrice(),
                stock.getChangePricePercentage(),
                stock.getLastVolume(),
                stock.getBuyPrice(),
                stock.getBuyQuantity(),
                stock.getSellPrice(),
                stock.getSellQuantity(),
                stock.getSecondBuyPrice(),
                stock.getSecondBuyQuantity(),
                stock.getSecondSellPrice(),
                stock.getSecondSellQuantity(),
                stock.getThirdBuyPrice(),
                stock.getThirdBuyQuantity(),
                stock.getThirdSellPrice(),
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );
        
        this.stock = s;
    }

    public void setLowPrice(double lowPrice) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getPrevPrice(),
                stock.getOpenPrice(),
                stock.getLastPrice(),
                stock.getHighPrice(),
                lowPrice,
                stock.getVolume(),
                stock.getChangePrice(),
                stock.getChangePricePercentage(),
                stock.getLastVolume(),
                stock.getBuyPrice(),
                stock.getBuyQuantity(),
                stock.getSellPrice(),
                stock.getSellQuantity(),
                stock.getSecondBuyPrice(),
                stock.getSecondBuyQuantity(),
                stock.getSecondSellPrice(),
                stock.getSecondSellQuantity(),
                stock.getThirdBuyPrice(),
                stock.getThirdBuyQuantity(),
                stock.getThirdSellPrice(),
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );
        
        this.stock = s;        
    }

    // TODO: CRITICAL LONG BUG REVISED NEEDED.
    public void setVolume(long volume) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getPrevPrice(),
                stock.getOpenPrice(),
                stock.getLastPrice(),
                stock.getHighPrice(),
                stock.getLowPrice(),
                volume,
                stock.getChangePrice(),
                stock.getChangePricePercentage(),
                stock.getLastVolume(),
                stock.getBuyPrice(),
                stock.getBuyQuantity(),
                stock.getSellPrice(),
                stock.getSellQuantity(),
                stock.getSecondBuyPrice(),
                stock.getSecondBuyQuantity(),
                stock.getSecondSellPrice(),
                stock.getSecondSellQuantity(),
                stock.getThirdBuyPrice(),
                stock.getThirdBuyQuantity(),
                stock.getThirdSellPrice(),
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );
        
        this.stock = s;        
    }

    public void setChangePrice(double changePrice) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getPrevPrice(),
                stock.getOpenPrice(),
                stock.getLastPrice(),
                stock.getHighPrice(),
                stock.getLowPrice(),
                stock.getVolume(),
                changePrice,
                stock.getChangePricePercentage(),
                stock.getLastVolume(),
                stock.getBuyPrice(),
                stock.getBuyQuantity(),
                stock.getSellPrice(),
                stock.getSellQuantity(),
                stock.getSecondBuyPrice(),
                stock.getSecondBuyQuantity(),
                stock.getSecondSellPrice(),
                stock.getSecondSellQuantity(),
                stock.getThirdBuyPrice(),
                stock.getThirdBuyQuantity(),
                stock.getThirdSellPrice(),
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );
        
        this.stock = s;        
    }

    public void setChangePricePercentage(double changePricePercentage) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getPrevPrice(),
                stock.getOpenPrice(),
                stock.getLastPrice(),
                stock.getHighPrice(),
                stock.getLowPrice(),
                stock.getVolume(),
                stock.getChangePrice(),
                changePricePercentage,
                stock.getLastVolume(),
                stock.getBuyPrice(),
                stock.getBuyQuantity(),
                stock.getSellPrice(),
                stock.getSellQuantity(),
                stock.getSecondBuyPrice(),
                stock.getSecondBuyQuantity(),
                stock.getSecondSellPrice(),
                stock.getSecondSellQuantity(),
                stock.getThirdBuyPrice(),
                stock.getThirdBuyQuantity(),
                stock.getThirdSellPrice(),
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );
        
        this.stock = s;        
    }

    public void setLastVolume(int lastVolume) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getPrevPrice(),
                stock.getOpenPrice(),
                stock.getLastPrice(),
                stock.getHighPrice(),
                stock.getLowPrice(),
                stock.getVolume(),
                stock.getChangePrice(),
                stock.getChangePricePercentage(),
                lastVolume,
                stock.getBuyPrice(),
                stock.getBuyQuantity(),
                stock.getSellPrice(),
                stock.getSellQuantity(),
                stock.getSecondBuyPrice(),
                stock.getSecondBuyQuantity(),
                stock.getSecondSellPrice(),
                stock.getSecondSellQuantity(),
                stock.getThirdBuyPrice(),
                stock.getThirdBuyQuantity(),
                stock.getThirdSellPrice(),
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );
        
        this.stock = s;        
    }

    public void setBuyPrice(double buyPrice) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getPrevPrice(),
                stock.getOpenPrice(),
                stock.getLastPrice(),
                stock.getHighPrice(),
                stock.getLowPrice(),
                stock.getVolume(),
                stock.getChangePrice(),
                stock.getChangePricePercentage(),
                stock.getLastVolume(),
                buyPrice,
                stock.getBuyQuantity(),
                stock.getSellPrice(),
                stock.getSellQuantity(),
                stock.getSecondBuyPrice(),
                stock.getSecondBuyQuantity(),
                stock.getSecondSellPrice(),
                stock.getSecondSellQuantity(),
                stock.getThirdBuyPrice(),
                stock.getThirdBuyQuantity(),
                stock.getThirdSellPrice(),
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );
        
        this.stock = s;        
    }

    public void setBuyQuantity(int buyQuantity) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getPrevPrice(),
                stock.getOpenPrice(),
                stock.getLastPrice(),
                stock.getHighPrice(),
                stock.getLowPrice(),
                stock.getVolume(),
                stock.getChangePrice(),
                stock.getChangePricePercentage(),
                stock.getLastVolume(),
                stock.getBuyPrice(),
                buyQuantity,
                stock.getSellPrice(),
                stock.getSellQuantity(),
                stock.getSecondBuyPrice(),
                stock.getSecondBuyQuantity(),
                stock.getSecondSellPrice(),
                stock.getSecondSellQuantity(),
                stock.getThirdBuyPrice(),
                stock.getThirdBuyQuantity(),
                stock.getThirdSellPrice(),
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );
        
        this.stock = s;        
    }

    public void setSellPrice(double sellPrice) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getPrevPrice(),
                stock.getOpenPrice(),
                stock.getLastPrice(),
                stock.getHighPrice(),
                stock.getLowPrice(),
                stock.getVolume(),
                stock.getChangePrice(),
                stock.getChangePricePercentage(),
                stock.getLastVolume(),
                stock.getBuyPrice(),
                stock.getBuyQuantity(),
                sellPrice,
                stock.getSellQuantity(),
                stock.getSecondBuyPrice(),
                stock.getSecondBuyQuantity(),
                stock.getSecondSellPrice(),
                stock.getSecondSellQuantity(),
                stock.getThirdBuyPrice(),
                stock.getThirdBuyQuantity(),
                stock.getThirdSellPrice(),
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );
        
        this.stock = s;        
    }

    public void setSellQuantity(int sellQuantity) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getPrevPrice(),
                stock.getOpenPrice(),
                stock.getLastPrice(),
                stock.getHighPrice(),
                stock.getLowPrice(),
                stock.getVolume(),
                stock.getChangePrice(),
                stock.getChangePricePercentage(),
                stock.getLastVolume(),
                stock.getBuyPrice(),
                stock.getBuyQuantity(),
                stock.getSellPrice(),
                sellQuantity,
                stock.getSecondBuyPrice(),
                stock.getSecondBuyQuantity(),
                stock.getSecondSellPrice(),
                stock.getSecondSellQuantity(),
                stock.getThirdBuyPrice(),
                stock.getThirdBuyQuantity(),
                stock.getThirdSellPrice(),
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );
        
        this.stock = s;
    }
    
    public void setSecondBuyPrice(double secondBuyPrice) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getPrevPrice(),
                stock.getOpenPrice(),
                stock.getLastPrice(),
                stock.getHighPrice(),
                stock.getLowPrice(),
                stock.getVolume(),
                stock.getChangePrice(),
                stock.getChangePricePercentage(),
                stock.getLastVolume(),
                stock.getBuyPrice(),
                stock.getBuyQuantity(),
                stock.getSellPrice(),
                stock.getSellQuantity(),
                secondBuyPrice,
                stock.getSecondBuyQuantity(),
                stock.getSecondSellPrice(),
                stock.getSecondSellQuantity(),
                stock.getThirdBuyPrice(),
                stock.getThirdBuyQuantity(),
                stock.getThirdSellPrice(),
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );
        
        this.stock = s;        
    }
    
    public void setSecondBuyQuantity(int secondBuyQuantity) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getPrevPrice(),
                stock.getOpenPrice(),
                stock.getLastPrice(),
                stock.getHighPrice(),
                stock.getLowPrice(),
                stock.getVolume(),
                stock.getChangePrice(),
                stock.getChangePricePercentage(),
                stock.getLastVolume(),
                stock.getBuyPrice(),
                stock.getBuyQuantity(),
                stock.getSellPrice(),
                stock.getSellQuantity(),
                stock.getSecondBuyPrice(),
                secondBuyQuantity,
                stock.getSecondSellPrice(),
                stock.getSecondSellQuantity(),
                stock.getThirdBuyPrice(),
                stock.getThirdBuyQuantity(),
                stock.getThirdSellPrice(),
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );
        
        this.stock = s;        
    }
    
    public void setSecondSellPrice(double secondSellPrice) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getPrevPrice(),
                stock.getOpenPrice(),
                stock.getLastPrice(),
                stock.getHighPrice(),
                stock.getLowPrice(),
                stock.getVolume(),
                stock.getChangePrice(),
                stock.getChangePricePercentage(),
                stock.getLastVolume(),
                stock.getBuyPrice(),
                stock.getBuyQuantity(),
                stock.getSellPrice(),
                stock.getSellQuantity(),
                stock.getSecondBuyPrice(),
                stock.getSecondBuyQuantity(),
                secondSellPrice,
                stock.getSecondSellQuantity(),
                stock.getThirdBuyPrice(),
                stock.getThirdBuyQuantity(),
                stock.getThirdSellPrice(),
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );
        
        this.stock = s;        
    }
    
    public void setSecondSellQuantity(int secondSellQuantity) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getPrevPrice(),
                stock.getOpenPrice(),
                stock.getLastPrice(),
                stock.getHighPrice(),
                stock.getLowPrice(),
                stock.getVolume(),
                stock.getChangePrice(),
                stock.getChangePricePercentage(),
                stock.getLastVolume(),
                stock.getBuyPrice(),
                stock.getBuyQuantity(),
                stock.getSellPrice(),
                stock.getSellQuantity(),
                stock.getSecondBuyPrice(),
                stock.getSecondBuyQuantity(),
                stock.getSecondSellPrice(),
                secondSellQuantity,
                stock.getThirdBuyPrice(),
                stock.getThirdBuyQuantity(),
                stock.getThirdSellPrice(),
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );
        
        this.stock = s;        
    }
    
    public void setThirdBuyPrice(double thirdBuyPrice) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getPrevPrice(),
                stock.getOpenPrice(),
                stock.getLastPrice(),
                stock.getHighPrice(),
                stock.getLowPrice(),
                stock.getVolume(),
                stock.getChangePrice(),
                stock.getChangePricePercentage(),
                stock.getLastVolume(),
                stock.getBuyPrice(),
                stock.getBuyQuantity(),
                stock.getSellPrice(),
                stock.getSellQuantity(),
                stock.getSecondBuyPrice(),
                stock.getSecondBuyQuantity(),
                stock.getSecondSellPrice(),
                stock.getSecondSellQuantity(),
                thirdBuyPrice,
                stock.getThirdBuyQuantity(),
                stock.getThirdSellPrice(),
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );
        
        this.stock = s;        
    }
    
    public void setThirdBuyQuantity(int thirdBuyQuantity) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getPrevPrice(),
                stock.getOpenPrice(),
                stock.getLastPrice(),
                stock.getHighPrice(),
                stock.getLowPrice(),
                stock.getVolume(),
                stock.getChangePrice(),
                stock.getChangePricePercentage(),
                stock.getLastVolume(),
                stock.getBuyPrice(),
                stock.getBuyQuantity(),
                stock.getSellPrice(),
                stock.getSellQuantity(),
                stock.getSecondBuyPrice(),
                stock.getSecondBuyQuantity(),
                stock.getSecondSellPrice(),
                stock.getSecondSellQuantity(),
                stock.getThirdBuyPrice(),
                thirdBuyQuantity,
                stock.getThirdSellPrice(),
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );
        
        this.stock = s;        
    }
    
    public void setThirdSellPrice(double thirdSellPrice) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getPrevPrice(),
                stock.getOpenPrice(),
                stock.getLastPrice(),
                stock.getHighPrice(),
                stock.getLowPrice(),
                stock.getVolume(),
                stock.getChangePrice(),
                stock.getChangePricePercentage(),
                stock.getLastVolume(),
                stock.getBuyPrice(),
                stock.getBuyQuantity(),
                stock.getSellPrice(),
                stock.getSellQuantity(),
                stock.getSecondBuyPrice(),
                stock.getSecondBuyQuantity(),
                stock.getSecondSellPrice(),
                stock.getSecondSellQuantity(),
                stock.getThirdBuyPrice(),
                stock.getThirdBuyQuantity(),
                thirdSellPrice,
                stock.getThirdSellQuantity(),
                stock.getCalendar()
                );
        
        this.stock = s;        
    }
    
    public void setThirdSellQuantity(int thirdSellQuantity) {
        final Stock s = new Stock(
                stock.getCode(),
                stock.getSymbol(),
                stock.getName(),
                stock.getBoard(),
                stock.getIndustry(),
                stock.getPrevPrice(),
                stock.getOpenPrice(),
                stock.getLastPrice(),
                stock.getHighPrice(),
                stock.getLowPrice(),
                stock.getVolume(),
                stock.getChangePrice(),
                stock.getChangePricePercentage(),
                stock.getLastVolume(),
                stock.getBuyPrice(),
                stock.getBuyQuantity(),
                stock.getSellPrice(),
                stock.getSellQuantity(),
                stock.getSecondBuyPrice(),
                stock.getSecondBuyQuantity(),
                stock.getSecondSellPrice(),
                stock.getSecondSellQuantity(),
                stock.getThirdBuyPrice(),
                stock.getThirdBuyQuantity(),
                stock.getThirdSellPrice(),
                thirdSellQuantity,
                stock.getCalendar()
                );
        
        this.stock = s;        
    } 
    
    private Stock stock;
}