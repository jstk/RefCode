package com.nexes.wizard;

import java.io.*;

public class WizardPanelNotFoundException extends RuntimeException {
        
    public WizardPanelNotFoundException() {
        super();
    }
     
    
}